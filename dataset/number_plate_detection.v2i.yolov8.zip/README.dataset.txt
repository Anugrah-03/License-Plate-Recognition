# number_plate_detection > 2023-09-11 3:32pm
https://universe.roboflow.com/college-zfiqb/number_plate_detection-kespk

Provided by a Roboflow user
License: CC BY 4.0

